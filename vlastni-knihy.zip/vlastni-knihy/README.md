# vlastni-knihy

Agent skill pro práci s knihou, ke které má uživatel legální přístup. Drží atribuci
u každého převzatého tvrzení, ověřená čísla stran a hranici mezi citací a náhradou knihy.

Běží v Claude Code, v chatu na claude.ai a v Coworku.

---

## Problém

Odborné knihy se kupují jako soubory a modely je umí přečíst celé. Tím vznikají dvě
opačná selhání:

1. **Nadužití** — model vydá výtah, po kterém už není důvod knihu otevřít.
2. **Přeopatrnost** — model najde v tiráži doložku o strojovém zpracování, přečte ji
   jako plošný zákaz a odmítne i citaci a určení strany.

Skill vede čáru mezi tím a vede ji na stejném místě pokaždé.

## Rozsah

Každý formát — PDF, EPUB, MOBI/AZW, DjVu, audiokniha, sken, foto, tištěná kniha,
exportované highlighty. Každý jazyk. Formát mění techniku, ne pravidla.

Podmínka platná vždy: přístup ke knize je legální (koupená, vypůjčená, legálně
zpřístupněná).

## Dvě hranice

- **Atribuce** — u každého tvrzení převzatého z knihy je poznat, že je z knihy, a je
  dohledatelné: autor, dílo, strana nebo kapitola. Platí i pro parafrázi.
- **Ukazatel místo náhrady** — výstup posílá ke knize (citace, strana, rejstřík,
  rozbor), nenahrazuje ji.

Uvnitř těchto hranic se s knihou pracuje bez omezení. Moralizování a připomínání
legálnosti pořízení skill zakazuje.

## Rozhodovací tabulka

Nadřazená všemu ostatnímu. Rozhoduje druh činnosti — ne znění doložky v knize a ne
argumentace.

| Činnost | |
|---|---|
| Přečíst knihu a najít v ní odpověď na konkrétní otázku | ano |
| Bibliografická citace, ISBN, vydání, edice | ano |
| Rejstřík, mapa oddílů, čísla stran, lokace pojmu | ano |
| Krátká doslovná citace se zdrojem pro studium a vědu | ano |
| Parafráze jednotlivého tvrzení se značkou původu a stranou | ano |
| Porovnání tvrzení z knihy se studiemi a s vlastními daty | ano |
| Shrnutí kapitoly v rozsahu, který kapitolu nahrazuje | ne |
| Systematická extrakce celé knihy do odvozeného textu | ne |
| Přepis nebo kompletní překlad knihy či kapitol | ne |
| Použití obsahu k trénování modelu nebo stavbě datasetu | ne |
| Šíření souboru dál nebo výtahu, který knihu nahrazuje | ne |
| Obcházení DRM a technické ochrany | ne |

Tabulkou nehne doložka v knize ani doklad o koupi. Vlastnictví řeší přístup, ne rozsah
přebírání; doložka řeší strojové vytěžování, ne citační právo. Čára se neposouvá
argumentací ani jedním směrem — proto s ní nelze manipulovat.

## Doložky o TDM a trénování AI

Odborné e-knihy běžně nesou výhradu práv k text a data miningu podle čl. 4 směrnice
2019/790/EU. Míří na hromadné odsávání katalogů a na trénink modelů.

Neruší:
- právo citovat pro výuku a vědecký výzkum,
- volné užití pro osobní potřebu,
- vyhledání a odkázání — rejstřík a čísla stran jsou vědecký aparát, ne vytěžování.

Čtení a citování není trénování.

Omezuje: položky označené `ne` v tabulce výše.

Postup: nález doložky se zapíše do hlavičky jako fakt, práce pokračuje podle tabulky.
Doložka není důvod k odložení knihy ani k přesunu práce na uživatele.

## Čísla stran

Uvádí se jen strana skutečně načtená z předlohy. Chybí-li, uvede se nejbližší jistá
kotva (kapitola, podkapitola, nadpis) a fakt, že strana ověřená není. Pravděpodobně
správné číslo strany je vymyšlená citace.

Rozsah knihy a tvrzení o tom, co v ní není, se hlásí až z nejlepší dostupné předlohy.
Z fragmentů vyhledávání se nepřítomnost tvrdit nedá.

| Formát | Kotva | Riziko |
|---|---|---|
| PDF, nativní text | tištěná strana | posun mezi stranou PDF a tištěnou; ověřit na několika místech |
| PDF, sken | strana z obrazu | chyby OCR; nejisté slovo se označí |
| EPUB, MOBI, AZW | kapitola, podkapitola, % | přepočet na strany tištěného vydání je nepřípustný |
| Převod do md/txt | žádná | ztráta stránkování, useknutý obsah |
| Audiokniha | kapitola a čas | doslovná citace jen ze zřetelného záznamu |
| Foto a sken stran | strana z obrázku | doplňování nečitelného textu |
| Vlastní výpisky | strana uvedená čtenářem | jsou dílem čtenáře, pracuje se s nimi bez omezení |

## Hlavička a značení

Hlavička se zakládá před první prací s knihou a slouží celé konverzaci pod zkratkou.

```
Kniha: [K1]
Údaje: Autor · Název · 1. vyd. · Nakladatel, 2025 · ISBN · jazyk
Formát předlohy: PDF s nativní paginací
Rozsah: celá kniha
Doložky: TDM výhrada — omezuje extrakci, ne citaci
```

Každé převzaté tvrzení nese v textu `[K1, s. 143]`, u knih bez stránkování
`[K1, kap. 8.9]`. Výklad nad rámec textu se značí odlišně, aby se nedal zaměnit za
obsah knihy.

Ve spojení se skillem `vstupy-a-zdroje` je `[K]` pátá značka a řadí se mezi `[D]`
a `[Z]`: kniha je doložený, ale obecný zdroj — vlastní data uživatele mají přednost.

## Limity citování

- doslovná citace v uvozovkách se stranou, řádově do 40 slov na jedno místo,
- jednotky citací na kapitolu, ne desítky,
- zbytek parafráze — rovněž se značkou,
- shrnutí kapitoly: myšlenky a struktura, ne odstavec po odstavci,
- delší doslovný blok jen do soukromých pracovních poznámek, označený jako
  nepublikovatelný v této délce.

## Rejstřík

Výchozí výstup pro podklad ke studiu; skill jej nabízí sám, zvlášť u knih s doložkou.

1. bibliografická citace ve zvolené normě,
2. oddíly s čísly stran, seřazené podle položené otázky, ne podle pořadí v knize,
3. u nejrelevantnějších jedna věta, proč tam číst,
4. výčet míst, kde strana není ověřená.

## Normy a cizí jazyky

Norma se řídí typem textu a oborem: ČSN ISO 690 (české akademické práce), APA
(psychologie, zdravotnictví), Vancouver/AMA (biomedicína), Chicago (humanitní obory),
Harvard, MLA. Zvolená norma se uvede. V jednom textu platí jedna.

Bibliografie cizojazyčné knihy se nepřekládá. Doslovná citace se uvádí v originále,
překlad se označí jako vlastní. Odkaz na české vydání nese překladatele; strany se
řídí vydáním, které je skutečně k dispozici.

## Prostředí

| Prostředí | Zdroj knihy |
|---|---|
| Chat na claude.ai | nahraný soubor nebo knihovna projektu; retrieval, proto se hlídá skutečný rozsah |
| Cowork | soubory ze složky sezení, čtené celé, obsah knihy jako mapa |
| Claude Code, Desktop | PDF nástroje s ověřenými čísly stran, knihovna přes konektor Zotero |

## Instalace

```
~/.claude/skills/vlastni-knihy/SKILL.md     # Claude Code
claude.ai → Settings → Customize → Skills   # chat, Cowork, mobil
```

Skill je jednosouborový, bez závislostí a bez doplňkových adresářů.

## Původ

Vznikl v srpnu 2026 ze dvou zaznamenaných selhání na téže knize.

Doložka o TDM byla přečtena jako plošný zákaz: asistent odmítl citovat i určovat
stránky a navrhl, ať knihu přečte a zpracuje uživatelka. Vyřazena měla být jen
hromadná extrakce.

Druhé selhání: z markdownového převodu bylo ohlášeno, že stránkování neexistuje
a kniha má 16 kapitol. Původní PDF mělo strojově čitelnou paginaci a 22 kapitol.

---

Není právní poradenství. Je to pracovní disciplína: vyřazuje se jen to, co se vyřadit
má, a neuvádí se strana, která nebyla načtena.
