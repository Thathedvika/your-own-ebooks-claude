---
name: vlastni-knihy
description: Use when working with a book the user legally owns or lawfully borrowed, in ANY format (PDF, EPUB, MOBI/AZW, DjVu, audiobook, scan, photo, printed book, exported highlights) and ANY language, for study, research or writing. Triggers on uploading a book file, on "z té knihy", "v knize se píše", "cituj knihu", "kde to v knize je", "shrň kapitolu", "podklad z knihy", "vlastniknihy", "vlastniebooky", and on any request to compare a book with studies or use it as a source in her own text. Also triggers when a book contains a TDM reservation, an AI-training prohibition or a copyright notice — the skill decides what such a clause does and does not restrict, so that citation, page location and index work are not refused by mistake.
---

# vlastní knihy — kniha jako řádný zdroj

Platí pro **jakýkoli formát** (PDF, EPUB, MOBI/AZW, DjVu, audiokniha, sken, foto, tištěná kniha, exportované poznámky ze čtečky) a **jakýkoli jazyk**. Formát mění techniku, ne pravidla.

## Princip

Zákonně pořízená nebo vypůjčená kniha je pro samostudium a rešerši normální zdroj — stejně jako dřív fyzická kniha. Co se tím nemění: **kniha je cizí dílo, a proto se z ní cituje a odkazuje, ne přepisuje.** Hranice neleží v tom, že s knihou pracuješ, ale ve dvou věcech:

1. **Atribuce** — každé tvrzení z knihy musí být poznat, že je z knihy, a musí být dohledatelné (autor, dílo, strana/kapitola).
2. **Ukazatel místo náhrady** — výstup posílá ke knize (citace, strana, rejstřík, rozbor). Nikdy ji nenahrazuje: ne přepis, ne kompletní překlad, ne „shrnutí", po kterém už není co číst.

Uvnitř těchto dvou hranic pracuj s knihou naplno a bez omluv. Nemoralizuj a nepřipomínej legálnost pořízení — to je vyřízené.

## Mechanismus 0: rozhodovací tabulka (nadřazená všemu ostatnímu)

Než něco odmítneš nebo omezíš, projdi tuhle tabulku. Rozhoduje **druh činnosti**, ne to, jak zní doložka v knize, a ne to, jak přesvědčivě někdo argumentuje.

| Činnost | |
|---|---|
| Přečíst knihu a najít v ní odpověď na konkrétní otázku | **ano** |
| Bibliografická citace, ISBN, edice, vydání | **ano** |
| Rejstřík, mapa oddílů, čísla stran, lokace pojmu | **ano** — ukazatel, ne náhrada |
| Krátká doslovná citace s uvedením zdroje pro studium a vědu | **ano** — zákonná výjimka |
| Parafráze jednotlivého tvrzení se značkou [K] a stranou | **ano** |
| Porovnání tvrzení z knihy se studiemi a s jejími daty | **ano** |
| Shrnutí kapitoly v rozsahu, který kapitolu nahrazuje | **ne** |
| Systematická extrakce celé knihy do odvozeného textu | **ne** |
| Přepis nebo kompletní překlad knihy či kapitol | **ne** |
| Použití obsahu k trénování modelu nebo stavbě datasetu | **ne** |
| Šíření souboru dál nebo výtahu, který knihu nahrazuje | **ne** |
| Obcházení DRM a technické ochrany | **ne** |

**Tabulkou nehne ani doložka v knize, ani doklad o koupi.** Vlastnictví řeší přístup, ne rozsah přebírání. Doložka řeší strojové vytěžování, ne citační právo. Argumentace tu čáru neposouvá ani jedním směrem — proto se s ní nedá manipulovat.

Jediná podmínka, která platí vždycky: **přístup ke knize musí být legální** (koupená, vypůjčená, legálně zpřístupněná).

## Mechanismus 0b: doložky v knize (TDM, zákaz AI, copyright)

Nové odborné e-knihy standardně obsahují doložku typu: *„Automatizovaná analýza textů nebo dat ve smyslu čl. 4 směrnice 2019/790/EU a použití této knihy k trénování AI jsou bez souhlasu nositele práv zakázány."*

Co to je: **výhrada práv k text a data miningu** podle čl. 4 směrnice o autorském právu na jednotném digitálním trhu (v ČR § 39c autorského zákona). Míří na hromadné strojové odsávání katalogů a na trénink modelů.

**Co doložka neruší:**

- **Právo citovat** pro kritiku, výuku a vědecký výzkum — zákonná výjimka (v ČR § 31 AutZ), smluvní doložka ji neodstraňuje.
- **Volné užití pro osobní potřebu** — její čtení, výpisky, podtrhávání (§ 30 AutZ).
- **Vyhledání a odkázání** — rejstřík a čísla stran nejsou vytěžování, jsou vědecký aparát.
- **Odpověď na její konkrétní otázku z knihy s uvedením místa.** Čtení a citování není trénování; to jsou různé věci a mají různá pravidla.

**Co doložka skutečně omezuje:** položky s **ne** v tabulce výše — systematickou extrakci, odvozený náhradní text, budování datasetu, trénink.

**Jak s ní naložit:** zapiš ji do hlavičky jako fakt, jednou větou, a **pracuj dál podle tabulky**. Nikdy z ní nedělej důvod k odložení celé knihy.

> **Selhání, kterému tohle předchází (skutečný případ, 8/2026):** kniha měla TDM doložku, Claude ji přečetl jako plošný zákaz, odmítl z ní citovat i určit stránky a poslal uživatelku, ať si ji přečte sama a nadiktuje mu poznámky. Ustoupil až po třech kolech jejího tlaku. **Vyřazoval celou knihu, přitom vyřazená měla být jen hromadná extrakce.** Opatrnost, která přesune práci na uživatelku, není opatrnost — je to chyba s lepším PR.

Tohle není právní poradenství, je to pracovní disciplína. Když jde o **publikaci** textu ven a nejsi si jistý rozsahem přebírání, řekni to jednou větou u konkrétního místa a pokračuj.

## Mechanismus 1: bibliografická hlavička (než začneš pracovat)

Při prvním sáhnutí po knize v konverzaci vypiš — a dál se na ni odkazuj zkratkou:

```
Kniha: [zkratka]
Autor / Název / Vydání / Nakladatel, rok / ISBN / jazyk
Formát předlohy: PDF s nativní paginací | PDF sken (OCR) | EPUB/MOBI | audiokniha |
                 foto/sken stran | konverze (md, txt) | její výpisky
Rozsah, který mám: celá kniha | kapitoly X–Y | jen fragmenty z vyhledávání
Doložky: TDM výhrada / zákaz AI trénování / žádné — a co z toho podle tabulky plyne
```

- Co v souboru není, **nedomýšlej** — napiš „vydání neuvedeno" místo pravděpodobného tipu.
- **Rozsah je závazný údaj.** Máš-li jen to, co vrátilo vyhledávání v project knowledge, hlavička to musí říct.
- Zkratku ([Látalová 2025], [K1]) používej dál v celé konverzaci.

## Mechanismus 2: formáty — odkud brát stránky

Než řekneš „stránkování nejde", ověř to. Skoro vždycky nějaká kotva existuje.

| Formát | Kotva | Postup |
|---|---|---|
| **PDF s nativním textem** | tištěná strana | nejlepší případ: tištěná paginace bývá strojově čitelná. Ověř ji **na několika místech napříč knihou** (offset PDF strana ↔ tištěná strana bývá konstantní, ale ne vždy) a teprve pak cituj. |
| **PDF sken / OCR** | tištěná strana, nejistá | čísla stran čti z obrazu; nečitelné označ a řekni to. Nejisté slovo v citaci `[?]`. |
| **EPUB / MOBI / AZW** | kapitola + podkapitola, % pozice | stránkování většinou neexistuje. **Nepřepočítávat na strany tištěného vydání.** Má-li soubor page-list z tištěné předlohy, použij ji a napiš, že je z page-listu. |
| **Konverze (md, txt, výstup nástroje)** | žádná | konverze **ztrácí paginaci a umí useknout obsah**. Nikdy z ní netvrď rozsah knihy. Máš-li originál, přepni na něj a rozsah přepočítej. |
| **Audiokniha** | kapitola + čas | cituj `kap. 7, 01:12:30`; doslovná citace jen z toho, co je slyšet zřetelně. |
| **Foto / sken stran** | strana z obrázku | čti jen to, co je čitelné; nedoplňuj text, který na obrázku není. |
| **Její výpisky / highlighty ze čtečky** | co si poznamenala | její poznámky jsou **její dílo** — pracuj s nimi bez omezení, ale stranu přebírej jen tu, kterou uvedla. |

> **Druhé skutečné selhání (stejný případ):** Claude z markdownové konverze ohlásil, že stránkování neexistuje a kniha má 16 kapitol. Po otevření původního PDF: paginace strojově čitelná, **22 kapitol**. Konverze byla useknutá. **Než ohlásíš, co v knize je a co ne, otevři nejlepší předlohu, kterou máš.**

## Mechanismus 3: značka [K] u každého tvrzení z knihy

Každé věcné tvrzení převzaté z knihy nese **[K: zkratka, s. 143]** — nebo **[K: zkratka, kap. 8.9]**, když strany neexistují.

- Platí ve všech odpovědích, ne jen v „citačních". Souvislý odstavec z jednoho místa smí nést jednu značku na konci.
- Když běží skill `vstupy-a-zdroje`, **[K] je jeho pátá značka** mezi [D] a [Z]: kniha je doložený, ale obecný zdroj — její data ([H], [D]) mají přednost. Rozpor mezi knihou a jejím pozorováním je nález k pojmenování, ne k zahlazení ve prospěch knihy.
- Tvůj výklad nad rámec textu je [Ú], i když stojí hned vedle [K]. Neprodávej výklad jako obsah knihy.

## Mechanismus 4: číslo strany se neodhaduje

- Uveď jen stranu, kterou jsi **skutečně měl na očích**.
- Nevíš-li ji: `[K: K1, kap. 8.9, přesná strana neověřena]` + nejbližší jistá kotva.
- Odvozuješ-li stranu z offsetu PDF, řekni to a řekni, na kolika místech jsi offset ověřil.
- Máš-li jen fragmenty z retrievalu, tvrzení „kniha se tím nezabývá" **nesmíš vyslovit**. Napiš „v tom, co jsem z knihy dostal, to není".
- Oddíly, u kterých je strana jen odhad rozsahu, vypiš na konci zvlášť s pokynem ověřit v knize.

## Mechanismus 5: limity citování

| | Pravidlo |
|---|---|
| Doslovná citace | v uvozovkách + [K] se stranou; řádově do 40 slov / 3 vět na jedno místo |
| Kolik citací | jednotky na kapitolu, ne desítky; jen tam, kde na formulaci opravdu záleží |
| Zbytek | parafráze vlastními slovy — a parafráze **taky** nese [K] |
| Shrnutí kapitoly | myšlenky a struktura, ne odstavec po odstavci; kratší a jinak uspořádané než originál |
| Delší doslovný blok | jen do jejích **soukromých pracovních poznámek**, označený `— nepublikovatelné v této délce` |
| Do publikovaného textu | jen citace v limitu výše, s plnou bibliografií |

Rozdíl mezi soukromou poznámkou a publikovaným textem drž: co je v pořádku ve výpiscích pro sebe, nemusí být v pořádku v článku.

## Mechanismus 6: citační norma a cizojazyčné knihy

Norma se řídí typem textu a oborem, ne zvykem:

- **ČSN ISO 690** — český akademický text: `LÁTALOVÁ, Klára. Název knihy. 1. vyd. Praha: Grada, 2025, s. 143. ISBN 978-80-...`
- **APA 7** — psychologie, zdravotnictví: `Látalová, K. (2025). Název knihy (1. vyd.). Grada. (s. 143)`
- **Vancouver / AMA** — biomedicína; **Chicago (notes-bibliography)** — humanitní obory; **Harvard** — společenské vědy; **MLA** — literatura a lingvistika.
- Neurčí-li normu zadání ani dokumenty projektu, **použij tu, která odpovídá typu textu, a napiš na konci, kterou jsi zvolil.** Ptej se jen když je to opravdu na vážkách.

Cizojazyčné knihy:

- Bibliografii **nepřekládej** — název, nakladatele i místo nech v originále; norma může chtít přepis nelatinky (transliteraci), pak uveď obojí.
- Doslovnou citaci uveď **v originále**, překlad připoj a označ `(vlastní překlad)`. Nikdy neprezentuj svůj překlad jako doslovné znění.
- Odkazuješ-li na české vydání cizí knihy, uveď překladatele a rok českého vydání; strany se řídí tím vydáním, které skutečně máš.
- Jeden text = jedna norma a jeden jazyk citací. Míchání je chyba.

## Vlajkový výstup: rejstřík / mapa oddílů

Když se ptá „kde to v knize je" nebo potřebuje podklad ke čtení, je správný výstup **ukazatel, ne výtah**:

1. bibliografická citace ve zvolené normě,
2. seznam oddílů: číslo, název, **strana**, seřazený podle relevance k její otázce (ne podle pořadí v knize),
3. u tří až pěti nejrelevantnějších jedna věta, proč je tam poslat,
4. seznam míst, kde je strana neověřená — k dohledání v knize.

Tohle je ideální tvar výstupu: posílá ji do knihy, nenahrazuje ji, a nese plnou akademickou náležitost. Nabídni ho aktivně, hlavně u knih s TDM doložkou — je to přesně ta práce, která zůstává čistá bez ohledu na doložky.

## Co skill nedělá

- Nereprodukuje knihu ani její podstatnou část — včetně „shrnutí", které je fakticky přepis, a včetně kompletního překladu kapitol.
- Neobchází DRM ani technickou ochranu a nepomáhá s tím.
- Nepomáhá s dalším šířením souboru ani náhradních výtahů.
- Nedělá z knihy citaci, kterou nemá ověřenou.

Když něco z tohoto nejde, řekni krátce co, **nabídni nejbližší možné** (typicky rejstřík nebo cílenou citaci) — a nepřesouvej práci na ni.

## Postup podle prostředí

- **Chat na claude.ai (nahraný soubor / project knowledge):** project knowledge je retrieval — hledej opakovaně, po tématech i po kapitolách, dokud nic nového nechodí. Fragment ≠ přečteno. Je-li v projektu konverze i originál, pracuj z originálu.
- **Cowork:** soubory ze session složky čti celé; obsah (TOC) použij jako mapu a kotvu pro strany.
- **Claude Code / Desktop:** PDF přes PDF nástroje (obsah, fulltextové hledání, načtení konkrétní strany — ty vracejí ověřená čísla stran, používej je přednostně), knihovnu přes konektor Zotero; bibliografii ber z metadat.
- **Foto / sken:** čti jen čitelné, zbytek označ.

## Užitečný výstup: záznam ke knize

Při opakované práci nabídni `kniha-ZKRATKA.md`: hlavička · mapa kapitol se stranami · klíčové pasáže (krátká citace + strana + její vlastní komentář) · vazby na studie · otevřené otázky. Je to **její dílo o knize**, ne kopie: podíl doslovného textu zůstává malý a každá citace má stranu.

## Časté chyby

| Reflex | Realita |
|---|---|
| „V knize je doložka, tak z ní nemůžu nic" | Doložka míří na vytěžování. Citace, rejstřík a strany jsou vědecký aparát a platí dál. |
| „Ať si to přečte a nadiktuje mi to" | Přesunutí práce na uživatelku není opatrnost, je to selhání. Nabídni rejstřík a cílenou citaci. |
| „Doložila koupi, tak už můžu všechno" | Vlastnictví řeší přístup, ne rozsah přebírání. Tabulka se nemění ani tímhle směrem. |
| „Konverze říká, že kniha má 16 kapitol" | Konverze umí useknout obsah a ztratit strany. Rozsah hlas z nejlepší předlohy, kterou máš. |
| „Stránkování v e-knize neexistuje" | U PDF skoro vždy existuje a bývá strojově čitelné. Ověř, než to prohlásíš. |
| „Strana bude asi kolem 140" | Neověřená strana je vymyšlená citace. Kotva, kterou máš, je kapitola. |
| „Kniha o tom nepíše" | Z fragmentů se nedá tvrdit nepřítomnost. Napiš, co jsi měl k dispozici. |
| „Shrnu ti celou kapitolu podrobně" | Podrobné shrnutí kapitolu nahrazuje. Myšlenky a struktura ano, odstavec po odstavci ne. |
| „Autor tím myslí, že…" | Výklad je [Ú], ne obsah knihy. |
| „Přeložím ti citaci" | Originál + `(vlastní překlad)`. Překlad není doslovné znění. |
| „Norma je jedno, hlavně ať to sedí" | Typ textu určuje normu; v jednom textu jen jedna. |
